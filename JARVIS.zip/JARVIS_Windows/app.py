import datetime
import json
import sqlite3
import subprocess
import threading
import tkinter as tk
from pathlib import Path
from tkinter import messagebox, scrolledtext

DB = Path(__file__).with_name('jarvis_memory.db')


def init_db():
    with sqlite3.connect(DB) as conn:
        conn.execute('CREATE TABLE IF NOT EXISTS history (id INTEGER PRIMARY KEY, role TEXT, message TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP)')


def remember(role, message):
    with sqlite3.connect(DB) as conn:
        conn.execute('INSERT INTO history(role, message) VALUES (?, ?)', (role, message))


def ask_ai(prompt):
    try:
        from openjarvis import Jarvis
        assistant = Jarvis()
        try:
            return str(assistant.ask('Responda em português do Brasil, de forma clara: ' + prompt))
        finally:
            assistant.close()
    except Exception as exc:
        return f'Não consegui acessar o OpenJarvis. Verifique a instalação e o modelo local. Detalhe: {exc}'


class App:
    def __init__(self, root):
        self.root = root
        root.title('JARVIS | Assistente Local')
        root.geometry('850x610')
        root.configure(bg='#0b1220')
        self.speak_enabled = tk.BooleanVar(value=True)
        tk.Label(root, text='J A R V I S', font=('Segoe UI', 28, 'bold'), fg='#61dafb', bg='#0b1220').pack(pady=15)
        tk.Label(root, text='ASSISTENTE PESSOAL • OPENJARVIS • WINDOWS', fg='#9db4c8', bg='#0b1220').pack()
        self.chat = scrolledtext.ScrolledText(root, bg='#131e30', fg='#e9f5ff', insertbackground='white', font=('Consolas', 11), wrap='word', state='disabled')
        self.chat.pack(fill='both', expand=True, padx=22, pady=18)
        bar = tk.Frame(root, bg='#0b1220')
        bar.pack(fill='x', padx=22, pady=(0, 18))
        self.entry = tk.Entry(bar, bg='#20314a', fg='white', insertbackground='white', font=('Segoe UI', 12), relief='flat')
        self.entry.pack(side='left', fill='x', expand=True, ipady=10)
        self.entry.bind('<Return>', lambda event: self.send())
        tk.Button(bar, text='Enviar', command=self.send, bg='#1b9cc8', fg='white').pack(side='left', padx=5)
        tk.Button(bar, text='🎤 Falar', command=self.listen, bg='#1b9cc8', fg='white').pack(side='left', padx=5)
        tk.Checkbutton(root, text='Ler respostas em voz alta', variable=self.speak_enabled, bg='#0b1220', fg='white', selectcolor='#20314a').pack(pady=(0, 12))
        self.add('JARVIS', 'Pronto. Diga “abrir bloco de notas”, “abrir calculadora” ou faça uma pergunta.')

    def add(self, who, msg):
        self.chat.configure(state='normal')
        self.chat.insert('end', f'{who}: {msg}\n\n')
        self.chat.see('end')
        self.chat.configure(state='disabled')

    def send(self):
        prompt = self.entry.get().strip()
        if not prompt:
            return
        self.entry.delete(0, 'end')
        self.add('VOCÊ', prompt)
        remember('user', prompt)
        actions = {'abrir bloco de notas': 'notepad.exe', 'abrir calculadora': 'calc.exe'}
        executable = actions.get(prompt.lower())
        if executable:
            if messagebox.askyesno('Confirmar ação', f'Permitir abrir {executable}?'):
                try:
                    subprocess.Popen([executable], shell=False)
                    self.finish('Aplicativo aberto com sua autorização.')
                except OSError as exc:
                    self.finish(f'Não consegui abrir o aplicativo: {exc}')
            else:
                self.finish('Ação cancelada.')
            return
        threading.Thread(target=self.reply, args=(prompt,), daemon=True).start()

    def reply(self, prompt):
        response = ask_ai(prompt)
        self.root.after(0, lambda: self.finish(response))

    def finish(self, response):
        self.add('JARVIS', response)
        remember('assistant', response)
        if self.speak_enabled.get():
            threading.Thread(target=self.speak, args=(response,), daemon=True).start()

    def speak(self, response):
        try:
            import pyttsx3
            engine = pyttsx3.init()
            engine.setProperty('rate', 175)
            engine.say(response[:600])
            engine.runAndWait()
        except Exception:
            pass

    def listen(self):
        threading.Thread(target=self.listen_worker, daemon=True).start()

    def listen_worker(self):
        try:
            import speech_recognition as sr
            recog = sr.Recognizer()
            with sr.Microphone() as mic:
                audio = recog.listen(mic, timeout=5, phrase_time_limit=12)
            # Uses Google's online speech recognition service; audio leaves the device.
            spoken = recog.recognize_google(audio, language='pt-BR')
            self.root.after(0, lambda: self.accept_voice(spoken))
        except Exception as exc:
            self.root.after(0, lambda: self.add('SISTEMA', f'Não foi possível reconhecer a fala: {exc}'))

    def accept_voice(self, spoken):
        self.entry.insert(0, spoken)
        self.send()


if __name__ == '__main__':
    init_db()
    root = tk.Tk()
    App(root)
    root.mainloop()
