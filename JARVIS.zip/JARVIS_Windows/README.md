# JARVIS Windows — protótipo Python

Este projeto é uma interface personalizada para o SDK do OpenJarvis. Não contém o código-fonte do OpenJarvis nem instala automaticamente o modelo.

## Instalação
1. Instale OpenJarvis conforme https://open-jarvis.github.io/OpenJarvis/getting-started/installation/ (Windows nativo).
2. Confira com `jarvis doctor` e `jarvis ask "Olá"`.
3. Instale Python 3.11–3.13 e abra PowerShell nesta pasta.
4. `py -3.11 -m venv .venv` (ajuste a versão se necessário).
5. `.\.venv\Scripts\python.exe -m pip install -r requirements.txt`
6. Certifique-se de que o SDK `openjarvis` esteja instalado no **mesmo ambiente Python** da interface. O instalador oficial pode usar outro ambiente; nesse caso, instale a interface e dependências no ambiente do OpenJarvis ou instale o SDK conforme a documentação oficial.
7. `.\.venv\Scripts\python.exe app.py`

## Recursos
- Chat com OpenJarvis via SDK Python
- Memória local de histórico em SQLite (grava, mas não injeta automaticamente histórico no contexto do modelo)
- Texto para fala offline via pyttsx3 (depende das vozes do Windows)
- Entrada por microfone via SpeechRecognition; `recognize_google` **usa serviço externo**, não é reconhecimento offline
- Abertura de Notepad e Calculadora mediante confirmação

## Limites e segurança
Apenas dois programas estão na lista de permissões. Não há execução de comandos arbitrários, exclusão de arquivos ou controle irrestrito do PC. Para reconhecimento de voz 100% offline, substitua a integração por um motor local como Vosk ou Whisper. A integração do SDK depende da versão instalada do OpenJarvis. Não compartilhe `jarvis_memory.db` sem revisar os dados pessoais salvos.
