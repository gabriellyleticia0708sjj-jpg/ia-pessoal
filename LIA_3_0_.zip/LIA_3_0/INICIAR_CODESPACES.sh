#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
python -m pip install -r requirements-web.txt
python app.py
