import os, sqlite3, threading
from pathlib import Path
from flask import Flask, render_template, request, jsonify
from ia_local import MotorIA
app=Flask(__name__)
app.config['MAX_CONTENT_LENGTH']=65536
DATA=Path(__file__).parent/'dados'; DATA.mkdir(exist_ok=True)
DB=DATA/'web.sqlite3'; lock=threading.Lock()
def db():
    c=sqlite3.connect(DB); c.execute('CREATE TABLE IF NOT EXISTS messages (id INTEGER PRIMARY KEY, chat TEXT, autor TEXT, texto TEXT)'); return c
@app.before_request
def protect():
    if request.method=='POST' and not request.is_json: return jsonify(error='JSON obrigatório'),415
@app.get('/')
def home(): return render_template('index.html')
@app.get('/api/history')
def history():
    with db() as c: rows=c.execute('SELECT chat,autor,texto FROM messages ORDER BY id DESC LIMIT 200').fetchall()
    return jsonify([dict(chat=r[0],autor=r[1],texto=r[2]) for r in reversed(rows)])
@app.post('/api/clear')
def clear():
    with lock, db() as c: c.execute('DELETE FROM messages')
    return jsonify(ok=True)
@app.post('/api/chat')
def chat():
    d=request.get_json(); msg=str(d.get('message','')).strip(); chat_id=str(d.get('chat',''))[:80]; model=str(d.get('model','llama3.2:1b'))[:120]; backend=d.get('backend','ollama')
    if not msg or len(msg)>12000 or not chat_id or backend not in ('ollama','openjarvis'): return jsonify(error='Pedido inválido'),400
    with lock:
        with db() as c: rows=c.execute('SELECT autor,texto FROM messages WHERE chat=? ORDER BY id DESC LIMIT 16',(chat_id,)).fetchall()
        try: answer=MotorIA(dict(backend=backend,modelo=model,openjarvis_model=model,openjarvis_url=os.getenv('OPENJARVIS_URL','http://127.0.0.1:8000'))).responder(msg,[dict(autor=r[0],texto=r[1]) for r in reversed(rows)])
        except Exception as e: return jsonify(error=str(e)),503
        with db() as c: c.executemany('INSERT INTO messages(chat,autor,texto) VALUES(?,?,?)',[(chat_id,'Você',msg),(chat_id,'LIA',answer)])
    return jsonify(answer=answer)
if __name__=='__main__': app.run(host='0.0.0.0' if os.getenv('CODESPACES') else '127.0.0.1',port=5000,debug=False)
