# LIA 3.0 — Windows / VS Code

Interface minimalista: menu de três pontos no canto superior esquerdo, esfera roxa animada, resposta central e caixa de mensagem inferior. Histórico, voz, palmas e configurações ficam no menu. Mantém os dois motores de IA da versão anterior: Ollama (padrão) e OpenJarvis (API compatível).

## Instalação

1. Extraia o ZIP. Abra a pasta `LIA_3_0` no VS Code.
2. Execute `INSTALAR_WINDOWS.bat` uma vez (ou `python -m venv .venv` e `.\.venv\Scripts\python.exe -m pip install -r requirements.txt`).
3. Instale Ollama de https://ollama.com/download/windows e baixe o modelo: `ollama pull llama3.2:1b`. Se o comando `ollama` não estiver no PATH, use `& "$env:LOCALAPPDATA\Programs\Ollama\ollama.exe" pull llama3.2:1b` no PowerShell.
4. Execute `INICIAR_LIA.bat` ou `.\.venv\Scripts\python.exe main.py`.
5. Menu `•••` → Configurações: motor `ollama`, modelo `llama3.2:1b`.

## Voz e palmas

- Menu `•••` → **Ouvir agora**: captura uma frase e reconhece pelo serviço Google de SpeechRecognition (requer internet).
- Menu `•••` → **Configurações** → **Ativação por duas palmas**: ativa o detector experimental de dois picos de áudio. O resultado depende do microfone e de ruídos externos.
- **Ativação por voz “LIA”**: utiliza Vosk local para detectar a palavra, sem internet após instalar o modelo. Baixe um modelo Vosk em português da página oficial https://alphacephei.com/vosk/models, extraia a pasta do modelo e **renomeie-a para `vosk-pt` dentro de `modelos`**. A estrutura final deve ser `modelos/vosk-pt/am`, `modelos/vosk-pt/conf`, etc. Em seguida, habilite “Ativação por voz” nas Configurações. O reconhecimento da frase após ativar usa Google e precisa de internet nesta versão.
- Para evitar concorrência pelo microfone, o monitor de palmas/palavra-chave pausa durante a escuta de um comando.
- A esfera anima enquanto aguarda, escuta, pensa e sintetiza a resposta. Não é uma sincronização fonética exata.

## Privacidade e limitações

- As conversas ficam em `dados/conversas.json`; configurações em `dados/config.json`.
- O modelo Ollama gera respostas localmente, mas o reconhecimento de comandos após a ativação usa serviço online. Não há gravação contínua de áudio em disco pelo aplicativo.
- O OpenJarvis só funciona se o servidor local já estiver instalado e disponível na URL configurada.
- A interface e o código foram verificados quanto à sintaxe, mas o microfone e os modelos precisam ser testados no seu Windows.
- Não há automação de controle do PC nesta versão; a LIA não executa comandos arbitrários do sistema.

## Versão web — GitHub Codespaces
A versão desktop permanece intacta. No terminal, dentro da pasta LIA_3_0:

```bash
python -m pip install -r requirements-web.txt
python app.py
```
Abra a porta 5000 na aba Portas (mantenha PRIVADA). Não instale requirements.txt para a versão web. O servidor é pessoal, sem autenticação própria; não exponha publicamente.

O Ollama deve rodar no próprio Codespace. Instale conforme https://ollama.com/download/linux, depois execute `ollama serve` em um terminal e `ollama pull llama3.2:1b` em outro. O modelo depende da RAM disponível. O Ollama do Windows não é acessível automaticamente. Para OpenJarvis, configure o servidor no Codespace e a variável OPENJARVIS_URL antes de iniciar app.py. Escolha o motor e modelo no menu.

Use Chrome ou Edge compatível, abra a página HTTPS encaminhada, permita microfone e habilite voz/palmas no menu. A Web Speech API pode usar internet e parar quando a aba fica em segundo plano. O detector de palmas é experimental; desligue o microfone pelo menu. O histórico web fica em dados/web.sqlite3, separado do histórico desktop. Não há controle do Windows pelo navegador. A animação reage ao estado da resposta, não ao áudio exato.
